<?php
/*
Plugin Name: Penpee Badges
Plugin URI: http://www.VibeThemes.com
Description: It will show the count of badges in the dashboard
Version: 1.0
Author: Diana
Author URI: http://www.VibeThemes.com
Text Domain: show-badges
Domain Path: /languages/
*/

/**
 * Register important functions for WPLMS
 *
 * @author      VibeThemes
 * @category    Admin
 * @package     Initialization
 * @version     1.0
 */

if ( !defined( 'ABSPATH' ) ) exit;
class penpee_badges_count{

    public static $instance;
    
    public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new penpee_badges_count();

        return self::$instance;
    }

    private function __construct(){
    
       add_shortcode('penpee_badges_count',array($this,'penpee_badges_count'));
    }

    function penpee_badges_count($atts, $content = null){
    if(current_user_can('administrator'))
    {
        global $wpdb;
        $blogusers = get_users( array( 'fields' => array( 'display_name' , 'id')));
        $total_user = count($blogusers);
        ?>
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
        <script scrc="https://code.jquery.com/jquery-3.3.1.js"></script>
         <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
         
        <script>
        $(document).ready(function() {
        $('#example').DataTable( {
        "order": [[ 3, "desc" ]]
        } );
        } );
    </script>
        <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Avatar</th>
                <th>Student Name</th>
                <th>Badge Count</th>
                <th>Course Title</th>
            </tr>
        </thead>
        <tbody>
            <?php

    if($total_user > 0 ){
         foreach ( $blogusers as $user ) {
?>
            <tr> 
                <td>
                  <?php 
                  echo get_avatar($user->id, 50 );
                  ?>
                </td>
                <td><?php echo esc_html( $user->display_name );?></td>
                <td>
                <?php
                $user_id = $user->id;
                $new=$wpdb->get_var($wpdb->prepare("
                SELECT meta_value
                FROM {$wpdb->usermeta}
                WHERE user_id = %d
                AND   meta_key LIKE %s",$user_id,'%badges%'
                ));


                $data = unserialize($new);
                if(empty($data)) echo 'N/A';
                else echo count($data);
                ?>
                </td>
                <td>
                    <?php
                    if(empty($data)) echo 'N/A';
                    else{
                        foreach ($data as $key=>$records)
                        {
                            echo '<li><a href="'.get_permalink( $records ).'">'.get_the_title( $records ).'</a></li><br>';
                        }
                    }
                    ?>
                </td>
            </tr>
<?php 
        }
    }

?>
        </tbody>
        <tfoot>
            <tr>
                <th>Avatar</th>
                <th>Student Name</th>
                <th>Badge Count</th>
                <th>Course Title</th>
            </tr>
        </tfoot>
    </table>
        <?php
    }

    }// function closed
}


penpee_badges_count::init();